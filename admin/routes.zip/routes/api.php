<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\LoginController;
use App\Http\Controllers\Api\IndexController;
use App\Http\Controllers\Api\AuthController;
/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/
/* 
Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
}); */


Route::post('login',[LoginController::class,'login']);
Route::post('register',[LoginController::class,'register']);

Route::get('post/{slug?}',[IndexController::class,'index']);

Route::post('hlike',[AuthController::class,'handlelike']);

Route::middleware(['auth:api'])->group(function(){
	
	//Route::post('handlelike',[LoginController::class,'logout']);
	
	Route::post('logout',[LoginController::class,'logout']);
});
