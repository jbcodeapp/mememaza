<?php

define('SITE_HEADING', 'Site Name');
define('ADMIN_PREFIX', '/');
define('IS_CASHE', false);
define('STORE_CACHE_TIME', 43200);
define('PUB', 'public/');
define('ACTIVE', 1);
define('IN_ACTIVE', 2);

define('FILE_ORIGINAL', 800);
define('FILE_PRODUCT_HOME_LIST', 801);
define('FILE_PRODUCT_DETAIL', 802);
define('FILE_PRODUCT_CAROUSEL', 803);
define('FILE_PRODUCT_CART', 804);

