<?php
 
namespace App\Http\Controllers\Api;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Validator, Auth, DB;
use App\Components\Api\CommonManager;
class AuthController extends Controller
{
	public function __construct()
    {
	   $this->middleware('auth:api');
    }
	
	public function handlelike(Request $request) {
		$user = auth()->user();
		$userid = $user->id;
		$type_id = $request->type_id;
		$commonManager = CommonManager::getInstance();
		
		$like = $commonManager->handleLikeStatus($userid, $type_id, 1);
		
		return response()->json(['statuscode'=>true, 'like' => $like], 200);
	}
}
