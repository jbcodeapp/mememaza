<?php
 
namespace App\Http\Controllers\Api;
use App\Http\Controllers\Controller;
use App\Components\Api\CommonManager;
use Illuminate\Http\Request;
use Validator, Auth, DB;
class IndexController extends Controller
{
	
    public function index(Request $request, $slug=null) {
		$obj = CommonManager::getInstance();
		$page = ($request->page > 0) ?  $request->page : 1;
		$limit = 3;
		
		$path=cdn(PUB."uploads/post");
		$postcol = [
				'posts.id', 'categories.name as category', 'posts.desc', 'posts.title', DB::raw('CONCAT("' . $path . '/","",posts.image) as image_path'),
				'posts.image', 'posts.like', 'posts.view', 'posts.share', 'posts.comment'
				];
		
		$path=cdn(PUB."category/");
		$categories = $obj->getCategories(['id', 'name', 'slug', 'image']);
		foreach($categories as $category) {
			$category->image_path = cdn(PUB.'category/'.$category->id.'/'.$category->image);
		}
		$post = $this->postData($page, $limit, $slug, $postcol);
		return response()->json(['statuscode'=>true, 'page' => $page, 'slug' => $slug, 'postcount' => $post['count'], 'categories' => $categories, 'post' => $post['data']], 200);
	}

	public function post(Request $request, $slug=null) {
		
		$page = ($request->page > 0) ?  $request->page : 1;
		$limit = 3;
		$path=cdn(PUB."uploads/post");
		$col = [
				'posts.id', 'categories.name as category', 'posts.desc', 'posts.title', DB::raw('CONCAT("' . $path . '/","",posts.image) as image_path'),
				'posts.image', 'posts.like', 'posts.view', 'posts.share', 'posts.comment'
				];
		
		return response()->json(['statuscode'=>true, 'post' => $this->postData($page, $limit, $slug, $col)], 200);
	}
	
	private function postData($page, $limit, $slug, $col) {
		
		$commonManagerObj = CommonManager::getInstance();
		return $post = $commonManagerObj->getPostsLimit($page, $limit, $slug, $col);
		
	}
}
